/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hadiah2a;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JPanel;
public class Hadiah2a extends JFrame{
    JTextField text = new JTextField();
    JButton angka1 = new JButton("1");
    JButton angka2 = new JButton("2");
    JButton angka3 = new JButton("3");
    JButton angka4  = new JButton("4");
    JButton angka5 = new JButton("5");
    JButton angka6 = new JButton("6");
    JButton angka7  = new JButton("7");
    JButton angka8  = new JButton("8");
    JButton angka9 = new JButton("9");
    JButton angka0 = new JButton("0");
    JButton titik = new JButton(".");
    JButton CE = new JButton("CE");
    
    
public Hadiah2a(){
    super(" Hadiah 2a Teori");
     setSize(300, 300);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JPanel pane = new JPanel();
     text.setBounds(5, 75, 230, 30);
   setLayout(new BorderLayout(0, 5));
   add(text, BorderLayout.NORTH);
   
   GridLayout family = new GridLayout(4, 4, 0, 0);
   pane.setLayout(family);
   
   pane.add(angka7);pane.add(angka8);pane.add(angka9);
   pane.add(angka4);pane.add(angka5);pane.add(angka6);
   pane.add(angka1);pane.add(angka2);pane.add(angka3);
   pane.add(angka0);pane.add(titik);pane.add(CE);
   
   add(pane);
   setVisible(true);

}
   
    public static void main(String[] args) {
        Hadiah2a frame = new Hadiah2a();
    }
    
}
